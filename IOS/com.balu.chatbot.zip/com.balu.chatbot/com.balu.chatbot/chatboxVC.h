//
//  chatboxVC.h
//  com.balu.chatbot
//
//  Created by Balu on 2017-07-18.
//  Copyright © 2017 Balu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface chatboxVC : UIViewController<UITableViewDataSource,UITableViewDelegate>
@property (weak, nonatomic) IBOutlet UITableView *chatlist;
@property NSMutableArray *chatpalceholder;
@property UIView *messageTextView;
@property NSString *botname;
@property (weak, nonatomic) IBOutlet UITextField *MessageTobeSent;

@end
