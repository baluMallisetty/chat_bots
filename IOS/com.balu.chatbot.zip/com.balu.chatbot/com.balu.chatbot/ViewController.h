//
//  ViewController.h
//  com.balu.chatbot
//
//  Created by Balu on 2017-07-18.
//  Copyright © 2017 Balu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>

@property (weak, nonatomic) IBOutlet UITableView *BotsTable;
@property NSMutableArray *botnames;

@end

