//
//  main.m
//  com.balu.chatbot
//
//  Created by Viswanatha Nakkinti on 2017-07-18.
//  Copyright © 2017 Balu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
