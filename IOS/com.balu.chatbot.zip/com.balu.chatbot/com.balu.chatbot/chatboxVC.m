//
//  chatboxVC.m
//  com.balu.chatbot
//
//  Created by Balu on 2017-07-18.
//  Copyright © 2017 Balu. All rights reserved.
//

#import "chatboxVC.h"
#import <QuartzCore/QuartzCore.h>

@interface chatboxVC ()

@end

@implementation chatboxVC

- (void)viewDidLoad {
    [super viewDidLoad];
    _messageTextView = [[UIView alloc]init];
    _chatpalceholder = [[NSMutableArray alloc]init];
    self.title = _botname;
    // Do any additional setup after loading the view.
}




#pragma mark - Table view Delegate Methods

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _chatpalceholder.count;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if ([[_chatpalceholder[indexPath.row]objectForKey:@"from"]isEqualToString:@"me"]) {
         UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"From"];
        if (!cell) {
            cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"From"];
        }
        cell.textLabel.text = [_chatpalceholder[indexPath.row]objectForKey:@"label"];
        cell.detailTextLabel.text = @"";
        cell.backgroundColor = [UIColor greenColor];
        return cell;
    }
    
    else{
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"To"];
        if (!cell) {
            cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"To"];
        }
        
        cell.detailTextLabel.text = [_chatpalceholder[indexPath.row]objectForKey:@"label"];
        cell.textLabel.text = @"";
        cell.detailTextLabel.textColor = [UIColor whiteColor];
        cell.backgroundColor = [UIColor blueColor];
        
        return cell;
    }
   

    return nil;
}





- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:(BOOL)animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark - Keyboard appearance/disappearance handling

- (void)keyboardWillAppear:(NSNotification *)notification
{
    NSDictionary *userInfo = [notification userInfo];
    CGSize keyboardSize = [[userInfo objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    
    UIEdgeInsets contentInsets = UIEdgeInsetsMake(0.0, 0.0, keyboardSize.height, 0.0);
    [self.chatlist setContentInset:contentInsets];
    [self.chatlist setScrollIndicatorInsets:contentInsets];
    
    CGRect messageFrame = self.messageTextView.frame;
    messageFrame.origin.y -= keyboardSize.height;
    [self.messageTextView setFrame:messageFrame];
}

- (void)keyboardWillDisappear:(NSNotification *)notification
{
    NSDictionary *userInfo = [notification userInfo];
    CGSize keyboardSize = [[userInfo objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.25];
    [self.chatlist setContentInset:UIEdgeInsetsZero];
    [UIView commitAnimations];
    [self.chatlist setScrollIndicatorInsets:UIEdgeInsetsZero];
    
    CGRect messageFrame = self.messageTextView.frame;
    messageFrame.origin.y += keyboardSize.height;
    [self.messageTextView setFrame:messageFrame];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (IBAction)sendButtonPressed:(id)sender {
    if (_MessageTobeSent.text && ![_MessageTobeSent.text isEqualToString:@""]) {
        NSMutableDictionary *message = [[NSMutableDictionary alloc]init];
        [message setObject:_MessageTobeSent.text forKey:@"label"];
        [message setObject:@"me" forKey:@"from"];
        
        [_chatpalceholder addObject:message];
        [_chatlist reloadData];
        _MessageTobeSent.text = @"";
        [self getReplyfromBot:[message objectForKey:@"label"]];
    }
}

-(void)getReplyfromBot:(NSString*)message{
    NSError *error;
    
    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    NSURLSession *session = [NSURLSession sessionWithConfiguration:configuration delegate:self delegateQueue:nil];
    NSURL *url = [NSURL URLWithString:@"http://localhost:3001/getdata"];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url
                                                           cachePolicy:NSURLRequestUseProtocolCachePolicy
                                                       timeoutInterval:60.0];
    
    [request addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [request addValue:@"application/json" forHTTPHeaderField:@"Accept"];
    
    [request setHTTPMethod:@"POST"];
    NSMutableDictionary *mapData = [[NSMutableDictionary alloc]init];
    [mapData setObject:message forKey:@"label"];
    [mapData setObject:_botname forKey:@"name"];
    
    NSData *postData = [NSJSONSerialization dataWithJSONObject:mapData options:0 error:&error];
    [request setHTTPBody:postData];
    
    
    NSURLSessionDataTask *postDataTask = [session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        NSDictionary *newJSON = [NSJSONSerialization JSONObjectWithData:data
                                                                options:0
                                                                  error:nil];
        dispatch_async(dispatch_get_main_queue(), ^{
            
            NSDictionary *topClassifer = [newJSON objectForKey:@"label"][0];
            double topClassifierValue = [[topClassifer objectForKey:@"value"]doubleValue];
            
            NSDictionary *secondClassifer = [newJSON objectForKey:@"label"][1];
            double secondClassifierValue = [[secondClassifer objectForKey:@"value"]doubleValue];
            
            if (topClassifierValue - secondClassifierValue >= 0.01) {
                [_chatpalceholder addObject:[newJSON objectForKey:@"label"][0]];
                [_chatlist reloadData];
            }
            else{
                //@[@"label",@"Sorry,Please ask relevent questions to my understanding!"]
                [_chatpalceholder addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"Sorry,Please ask relevent questions to my understanding!",@"label", nil]];
                [_chatlist reloadData];
            }
            
        });
        
    }];
    
    [postDataTask resume];
}

@end
